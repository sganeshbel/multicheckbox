
function validate(){
	var link = document.createElement('link');  
	  
    // set the attributes for link element 
       link.rel = 'stylesheet';  
  
    link.type = 'text/css'; 
  
    link.href = 'js/jquery-ui.css';  

	document.write("<link href = 'js/jquery-ui.css' rel = 'stylesheet'>");
	document.write("<script src = 'js/jquery-1.10.2.js'></scrip>");
			document.write("<script src = 'js/jquery-ui.js'></script>");
	document.write("<input type='text'id='datepicker-12'>");	
	
	
	var imported = document.createElement('script');
	imported.src = 'js/jquery-1.10.2.js';
	document.head.appendChild(imported);
	$.getScript('js/jquery-1.10.2.js', function()
			{
		$("#datepicker-12").click(function() {
			alert("hi");
	        $( "#datepicker-12" ).datepicker();
	     $( "#datepicker-12" ).datepicker("show");
	     });
			})
	
	
	
}
